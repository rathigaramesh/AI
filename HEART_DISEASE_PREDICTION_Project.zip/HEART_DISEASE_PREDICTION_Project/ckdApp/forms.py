from django import forms
from .models import *


class ckdForm(forms.ModelForm):
    class Meta():
        model=ckdModel
        #fields=['Blood_Glucose_Random','Blood_Urea','Serum_Creatine','Packed_cell_volume','White_blood_count']
        fields = [
    'age',
    'sex_male',         # Boolean: Is male
    'cp',               # Chest pain
    'trestbps',         # Resting blood pressure
    'chol',             # Cholesterol
    'fbs',              # Fasting blood sugar
    'restecg',          # Resting ECG
    'thalach',          # Max heart rate
    'exang',            # Exercise-induced angina
    'oldpeak',          # ST depression
    'slope',            # Slope of ST segment
    'ca',               # Major vessels
    'thal'              # Thalassemia
]


            
     
    
     
      
      
      
      
      
     
