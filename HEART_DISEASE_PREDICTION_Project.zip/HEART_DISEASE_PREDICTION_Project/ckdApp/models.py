from django.db import models

# Create your models here.
class ckdModel(models.Model):

    # Blood_Glucose_Random=models.FloatField()
    # Blood_Urea=models.FloatField()
    # Serum_Creatine=models.FloatField()
    # Packed_cell_volume=models.FloatField()
    # White_blood_count=models.FloatField()
    age = models.IntegerField()
    cp = models.IntegerField()
    trestbps = models.FloatField()
    chol = models.FloatField()
    fbs = models.IntegerField()
    restecg = models.IntegerField()
    thalach = models.FloatField()
    exang = models.IntegerField()
    oldpeak = models.FloatField()
    slope = models.IntegerField()
    ca = models.IntegerField()
    thal = models.IntegerField()
    sex_male = models.BooleanField()
